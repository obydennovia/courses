public class Main {
    public static void main(String[] args) {
        Arithmetic arithmetic = new Arithmetic(100,101);

        arithmetic.sumAB();
        arithmetic.multiAB();
        arithmetic.maxAB();
        arithmetic.minAB();
    }
}
